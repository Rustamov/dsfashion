# Шаблон для быстрого старта проектов

* [Как начать проект](readme/how-to-start-project.md)
* [Установка зависимостей и запуск](readme/install-and-start.md)

